package org.firstinspires.ftc.teamcode.opmodes;

import com.qualcomm.robotcore.eventloop.opmode.OpMode;
import com.qualcomm.robotcore.eventloop.opmode.TeleOp;

import org.firstinspires.ftc.teamcode.RobotHardware;

/**
 * Mecanum TeleOp with field-centric / robot-centric toggle and slow mode.
 *
 * Controls (gamepad1):
 *   Left stick    - drive (forward/back + strafe)
 *   Right stick X - rotate
 *   Right bumper  - hold for slow mode
 *   Y             - toggle field-centric / robot-centric
 *   Back          - reset heading (do this with the robot facing away from you)
 */
@TeleOp(name = "Mecanum TeleOp", group = "Drive")
public class MecanumTeleOp extends OpMode {

    private static final double SLOW_MODE_SCALE = 0.3;

    private RobotHardware hw;

    private boolean fieldCentric = true;
    private boolean yWasPressed = false;

    @Override
    public void init() {
        hw = new RobotHardware(hardwareMap);
        hw.init();

        telemetry.addLine("Ready. Y = toggle field-centric, Back = reset heading.");
        telemetry.update();
    }

    @Override
    public void loop() {
        // Edge detection so holding Y toggles only once
        if (gamepad1.y && !yWasPressed) {
            fieldCentric = !fieldCentric;
        }
        yWasPressed = gamepad1.y;

        if (gamepad1.back) {
            hw.resetHeading();
        }

        double forward = -gamepad1.left_stick_y; // stick up is negative
        double strafe  = gamepad1.left_stick_x;
        double turn    = gamepad1.right_stick_x;

        double heading = hw.getHeading();

        if (fieldCentric) {
            double rotStrafe  = strafe * Math.cos(-heading) - forward * Math.sin(-heading);
            double rotForward = strafe * Math.sin(-heading) + forward * Math.cos(-heading);
            strafe = rotStrafe;
            forward = rotForward;
        }

        double scale = gamepad1.right_bumper ? SLOW_MODE_SCALE : 1.0;
        hw.drive(forward, strafe, turn, scale);

        telemetry.addData("Mode", fieldCentric ? "Field-centric" : "Robot-centric");
        telemetry.addData("Slow mode", gamepad1.right_bumper);
        telemetry.addData("Heading (deg)", "%.1f", Math.toDegrees(heading));
        telemetry.update();
    }

    @Override
    public void stop() {
        if (hw != null) {
            hw.stopDrive();
        }
    }
}
