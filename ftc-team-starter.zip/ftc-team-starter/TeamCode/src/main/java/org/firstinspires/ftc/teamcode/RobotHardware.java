package org.firstinspires.ftc.teamcode;

import com.qualcomm.hardware.rev.RevHubOrientationOnRobot;
import com.qualcomm.robotcore.hardware.DcMotor;
import com.qualcomm.robotcore.hardware.DcMotorSimple;
import com.qualcomm.robotcore.hardware.HardwareMap;
import com.qualcomm.robotcore.hardware.IMU;

import org.firstinspires.ftc.robotcore.external.navigation.AngleUnit;

/**
 * Single place where every motor and sensor is set up.
 * Both TeleOp and Autonomous use this class, so a change here
 * (like flipping a motor direction) fixes it everywhere.
 *
 * Device names must match docs/HARDWARE_CONFIG.md exactly.
 */
public class RobotHardware {

    public DcMotor leftFront, leftBack, rightFront, rightBack;
    public IMU imu;

    private final HardwareMap hardwareMap;

    public RobotHardware(HardwareMap hardwareMap) {
        this.hardwareMap = hardwareMap;
    }

    /** Call once in init(). */
    public void init() {
        leftFront  = hardwareMap.get(DcMotor.class, "leftFront");
        leftBack   = hardwareMap.get(DcMotor.class, "leftBack");
        rightFront = hardwareMap.get(DcMotor.class, "rightFront");
        rightBack  = hardwareMap.get(DcMotor.class, "rightBack");

        // If the robot drives backwards or spins in place, flip these.
        leftFront.setDirection(DcMotorSimple.Direction.REVERSE);
        leftBack.setDirection(DcMotorSimple.Direction.REVERSE);
        rightFront.setDirection(DcMotorSimple.Direction.FORWARD);
        rightBack.setDirection(DcMotorSimple.Direction.FORWARD);

        for (DcMotor m : new DcMotor[]{leftFront, leftBack, rightFront, rightBack}) {
            m.setZeroPowerBehavior(DcMotor.ZeroPowerBehavior.BRAKE);
            m.setMode(DcMotor.RunMode.RUN_WITHOUT_ENCODER);
        }

        imu = hardwareMap.get(IMU.class, "imu");
        // Match how the Control Hub is physically mounted.
        imu.initialize(new IMU.Parameters(new RevHubOrientationOnRobot(
                RevHubOrientationOnRobot.LogoFacingDirection.UP,
                RevHubOrientationOnRobot.UsbFacingDirection.FORWARD)));
    }

    /** Heading in radians. */
    public double getHeading() {
        return imu.getRobotYawPitchRollAngles().getYaw(AngleUnit.RADIANS);
    }

    public void resetHeading() {
        imu.resetYaw();
    }

    /**
     * Drive using robot-centric inputs.
     * @param forward  -1..1, positive = forward
     * @param strafe   -1..1, positive = right
     * @param turn     -1..1, positive = clockwise
     * @param scale    overall speed multiplier (1.0 = full speed)
     */
    public void drive(double forward, double strafe, double turn, double scale) {
        strafe *= 1.1; // counteract imperfect strafing

        double denominator = Math.max(Math.abs(forward) + Math.abs(strafe) + Math.abs(turn), 1.0);

        leftFront.setPower((forward + strafe + turn) / denominator * scale);
        leftBack.setPower((forward - strafe + turn) / denominator * scale);
        rightFront.setPower((forward - strafe - turn) / denominator * scale);
        rightBack.setPower((forward + strafe - turn) / denominator * scale);
    }

    public void stopDrive() {
        drive(0, 0, 0, 0);
    }
}
