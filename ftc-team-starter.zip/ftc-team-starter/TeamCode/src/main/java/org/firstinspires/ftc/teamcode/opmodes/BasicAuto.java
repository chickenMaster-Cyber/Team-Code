package org.firstinspires.ftc.teamcode.opmodes;

import com.qualcomm.robotcore.eventloop.opmode.Autonomous;
import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;

import org.firstinspires.ftc.teamcode.RobotHardware;

/**
 * Simple timed autonomous: drive forward, strafe right, stop.
 * Timed movement is NOT accurate (it depends on battery voltage), so use this
 * to learn the structure, then move to encoders or a path library.
 *
 * Tune the powers and durations on your own robot.
 */
@Autonomous(name = "Basic Auto (timed)", group = "Auto", preselectTeleOp = "Mecanum TeleOp")
public class BasicAuto extends LinearOpMode {

    @Override
    public void runOpMode() {
        RobotHardware hw = new RobotHardware(hardwareMap);
        hw.init();

        telemetry.addLine("Ready. Press PLAY.");
        telemetry.update();

        waitForStart();

        if (opModeIsActive()) {
            // Drive forward for 1.0 seconds at 40% power
            hw.drive(0.4, 0, 0, 1.0);
            sleep(1000);

            // Strafe right for 0.8 seconds
            hw.drive(0, 0.4, 0, 1.0);
            sleep(800);

            hw.stopDrive();
        }

        telemetry.addLine("Done.");
        telemetry.update();
    }
}
