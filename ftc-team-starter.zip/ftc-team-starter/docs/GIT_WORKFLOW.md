# Git Workflow

We use branches and pull requests so two people never overwrite each other's work.

## Daily routine

1. **Update main**
   - Git > Pull (while on `main`)
2. **Make a branch** for what you are working on
   - Git > New Branch, name it like `alex/arm-control` or `fix/strafe-direction`
3. **Code and test**
4. **Commit often** with clear messages
   - Good: `Add intake motor and button mapping`
   - Bad: `stuff`, `fixed it`
5. **Push your branch**
   - Git > Push
6. **Open a pull request** on GitHub
   - Click the yellow "Compare & pull request" banner
   - Describe what changed and how you tested it
7. **Get one teammate to review**, then click **Merge**
8. **Delete the branch** after merging and pull `main` again

## Rules

- Never push directly to `main`.
- Never commit `local.properties`, build folders, or `.idea/` (the `.gitignore` handles this).
- If you get a merge conflict, ask for help before choosing "accept theirs/yours".
- Do not merge code that has not been tested on the robot (at least on blocks).

## Before a competition

- Tag the working code: `git tag qualifier-1` and push the tag.
- Keep a known-good copy of the code on the Control Hub and on a laptop.
