# Pre-Match / Practice Checklist

## Robot
- [ ] Battery charged and secured
- [ ] Wires clear of wheels and moving parts
- [ ] Control Hub and Driver Station both show the same configuration

## Software
- [ ] Latest `main` deployed to the Control Hub
- [ ] OpMode appears in the Driver Station list
- [ ] INIT runs without errors

## On blocks (wheels off the ground)
- [ ] Push left stick forward: all four wheels spin forward
- [ ] Push left stick right: strafes right
- [ ] Push right stick right: robot turns clockwise
- [ ] Slow mode (right bumper) noticeably slower
- [ ] Heading telemetry changes when you rotate the robot by hand
- [ ] Back button resets heading to 0

## On the floor
- [ ] Drives straight when pushed straight
- [ ] Stops quickly when sticks are released
- [ ] Autonomous runs the same twice in a row
