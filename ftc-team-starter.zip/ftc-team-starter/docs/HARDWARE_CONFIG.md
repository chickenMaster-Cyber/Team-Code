# Hardware Configuration

Device names in the robot configuration (Driver Station > Configure Robot) **must match
these exactly**, including capital letters. Update this file whenever the robot changes.

## Control Hub

### Motors
| Port | Name | Notes |
|------|------|-------|
| 0 | `leftFront` | Left side reversed in code |
| 1 | `leftBack` | Left side reversed in code |
| 2 | `rightFront` | |
| 3 | `rightBack` | |

### Servos
| Port | Name | Notes |
|------|------|-------|
| 0 | | Add as you build |

### I2C sensors
| Bus/Port | Name | Notes |
|----------|------|-------|
| Built-in | `imu` | Control Hub IMU |

## Hub mounting
The IMU needs to know how the hub is mounted. Current setting in `RobotHardware.java`:
- Logo facing: **UP**
- USB facing: **FORWARD**

If you remount the hub, change these two values or field-centric driving will be wrong.
