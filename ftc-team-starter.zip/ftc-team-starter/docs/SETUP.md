# Software Setup

## 1. Install tools
- [Android Studio](https://developer.android.com/studio) (latest stable)
- [Git](https://git-scm.com/downloads)
- A GitHub account (one per person)

## 2. Get the code
1. Go to the team repo on GitHub and click **Code** to copy the URL.
2. In Android Studio: **File > New > Project from Version Control**.
3. Paste the URL, choose a folder, click **Clone**.
4. Wait for Gradle sync to finish (first time takes a few minutes).

If the team repo does not exist yet, one person forks
`FIRST-Tech-Challenge/FtcRobotController` into the team's GitHub account,
then adds everyone as collaborators under **Settings > Collaborators**.

## 3. Sign in to GitHub in Android Studio
**Settings > Version Control > GitHub > Add Account**. A browser window opens
to approve the login.

## 4. Build and deploy
1. Connect to the Control Hub over USB, or over Wi-Fi (the hub's `FTC-xxxx` network).
2. Pick the **TeamCode** run configuration and the connected device.
3. Click **Run**. The Robot Controller app updates on the hub.
4. On the Driver Station phone, choose your OpMode from the TeleOp or Autonomous list.

## 5. Troubleshooting
- **Gradle sync fails:** check your internet connection, then **File > Invalidate Caches**.
- **Device not found:** unplug and replug USB, or run `adb devices` in a terminal.
- **Crash on INIT:** a device name in code does not match the robot configuration.
  Compare with `HARDWARE_CONFIG.md`.
