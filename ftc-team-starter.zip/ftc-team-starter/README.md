# FTC Team Code

Robot code for our FIRST Tech Challenge team, built on the official
[FtcRobotController](https://github.com/FIRST-Tech-Challenge/FtcRobotController) SDK.

## Quick start

1. Fork or clone the official FtcRobotController repo (see `docs/SETUP.md`).
2. Copy the contents of this kit's `TeamCode/` folder into the SDK's `TeamCode/` folder.
3. Open the project in Android Studio and let Gradle sync.
4. Build and deploy to the Control Hub (`docs/SETUP.md` has the steps).

## What's in here

| Path | Purpose |
|------|---------|
| `TeamCode/.../RobotHardware.java` | One place that maps and configures every motor and sensor |
| `TeamCode/.../opmodes/MecanumTeleOp.java` | Driver-controlled program (field-centric, slow mode) |
| `TeamCode/.../opmodes/BasicAuto.java` | Simple timed autonomous to practice with |
| `docs/SETUP.md` | Software setup, step by step |
| `docs/GIT_WORKFLOW.md` | How we use branches and pull requests |
| `docs/HARDWARE_CONFIG.md` | Names of every device in the robot configuration |
| `docs/TESTING_CHECKLIST.md` | What to check before every practice or match |

## Team rules

- Never push straight to `main`. Make a branch, open a pull request, get one review.
- Device names in code must match `docs/HARDWARE_CONFIG.md` exactly.
- Test on blocks before the robot touches the floor.
- Write a clear commit message: what changed and why.

## Team

Add your team number, name, and members here.
